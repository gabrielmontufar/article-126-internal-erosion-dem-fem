﻿Reproducible computational evidence for Article 126.

Target journal: Computers and Geotechnics.

Public repository declared by the manuscript:
https://github.com/gabrielmontufar/article-126-internal-erosion-dem-fem/releases/tag/v1.0.7-theory-proof-20260531

This package is a synthetic numerical-method benchmark and not an operational
dam-safety model.

Novelty claim for the Computers and Geotechnics submission:

- The contribution is a selective multiscale activation operator, not a routine
  FEM, graph-search or DEM application in isolation.
- A user-implemented continuum dam model supplies hydraulic and erosion state
  variables; a Dijkstra graph converts those states into a connected
  exit-to-source erosion corridor; and a bonded-particle DEM micro-window is
  activated only on that corridor.
- Component-ablation evidence compares the full FEM-Dijkstra-DEM screening
  model against critical-gradient, FEM-only, FEM-Dijkstra-without-DEM and
  empirical baselines, keeping the claim bounded to screening rather than
  operational safety forecast.

Primary command for evaluators:

`python code/run_all_article_126_reproducibility.py`

Portable checksums are provided in `CHECKSUMS_Q1_FINAL_SHA256.txt` using POSIX relative
paths with `/`.

This command rebuilds the complete local evidence set:

- `code/reproduce_article_126_clean.py`: legacy manufactured 1D verification, synthetic 2D screening benchmark, sensitivity, mesh check and Figures 1-5. This script preserves the original figure-generation pathway; the current theoretical FEM-Dijkstra-DEM screening operator is implemented in `code/hybrid_dem_fem_graph_benchmark.py`.
- `code/hybrid_dem_fem_graph_benchmark.py`: executable claim-code closure with a triangular 2D finite-element Darcy solver, Dijkstra lowest-cost path over cells and a bonded-particle DEM micro-window with bond breakage and homogenized return quantities.
- `code/external_validation_lee2021.py`: bounded external empirical challenge based on Lee, Kim and Chung (2021).
- `code/novelty_validation_scorecard.py`: novelty matrix against recent Computers and Geotechnics suffusion literature and bounded quantitative Lee et al. (2021) screening validation metrics.
- `code/external_ab_validation_baselines.py`: calibration subset A, held-out subset B and baseline comparison against critical-gradient, FEM-only, FEM-Dijkstra-without-DEM and simple empirical models.

The key file for addressing the strict review-benchmark claim-code objection is:

`data/hybrid_fem_dijkstra_dem_summary.json`

The key file for the mathematical-consistency objection is:

`mathematical_consistency_note.md`

It records the operator properties, normalized weight constraints and
Proposition 1 used to support the theoretical/mathematical score.

The key files for the review-benchmark novelty and validation/comparison criteria are:

- `data/novelty_matrix_cg_recent.csv`
- `data/lee2021_quantitative_screening_validation.csv`
- `data/lee2021_validation_metrics.csv`
- `data/novelty_validation_summary.json`
- `data/external_validation_ab_cases.csv`
- `data/external_validation_baseline_definitions.csv`
- `data/external_ab_validation_predictions.csv`
- `data/external_ab_validation_metrics.csv`
- `data/novelty_efficiency_metrics.csv`
- `data/external_ab_validation_summary.json`
- `data/validation_levels_3_5_evidence.csv`
- `data/validation_editorial_sentence.txt`

The novelty-efficiency file reports two ablation quantities requested by the
novelty audit: `Connectivity Gain`, which measures the fines-loss MAE reduction
from adding the Dijkstra path layer to the FEM-only baseline, and `DEM
Activation Efficiency`, which measures the DEM-closure MAE reduction per
activated Dijkstra-corridor domain fraction.

Additional external challenge added for the Computers and Geotechnics revision:

- Run `python code/external_validation_lee2021.py`.
- It creates `data/external_lee2021_observations.csv`, `data/external_validation_challenge_results.csv`, and `data/external_validation_summary.json`.
- The source is Lee, Kim and Chung (2021), International Journal of Geo-Engineering, DOI 10.1186/s40703-021-00151-6.
- This is a bounded external empirical challenge. It supports the need for a path/history-sensitive screening indicator because published long-term suffusion occurred below short-term critical-gradient values. It is not quantitative field validation and must not be described as deployed operational dam-safety validation.

Additional Q1-high external mechanism challenge added in the working upgrade:

- `data/external_deng2020_horizontal_suffusion_challenge.csv`
- `data/external_deng2020_claim_boundary_note.txt`
- The source is Deng, Zhang, Chen, Liu, Shu and Zhou (2020), Frontiers in Earth Science, DOI 10.3389/feart.2020.00195.
- This source reports horizontal seepage-induced suffusion under controlled vertical stress with seepage flux, eroded fine-particle mass and local hydraulic-gradient measurements. It is used as an external mechanism challenge supporting path-aware screening and the inadequacy of a pure global critical-gradient cutoff. It is not used as calibration, A/B validation, field validation or proof that the proposed FEM-Dijkstra-DEM model predicts the Deng et al. tests.

Additional open primary endpoint directionality gate:

- `code/external_wan2025_internal_erosion_endpoint_gate.py`
- `data/external_wan2025_internal_erosion_endpoints.csv`
- `data/external_wan2025_internal_erosion_endpoint_gate_metrics.csv`
- `data/external_wan2025_internal_erosion_endpoint_gate_summary.json`
- The source is Wan, Pan, Luo and Peng (2025), Scientific Reports, DOI 10.1038/s41598-025-06012-x.
- This source reports flow-rate endpoints for granite residual soil: wetting-front arrival at 100 cm and cumulative fine-particle loss over 90 min for 25, 50 and 100 L/H. It is used only as an open primary endpoint directionality gate showing that higher flow rates accelerate front arrival and increase cumulative erosion. It is not Chang/Sterpi/Zhu residual validation, raw trajectory validation, field validation or proof that the proposed FEM-Dijkstra-DEM model predicts the Wan et al. tests.

Additional second-family residual endpoint validation:

- `code/external_validation_ke_takahashi2012_second_family_residuals.py`
- `data/external_ke_takahashi2012_a60_observations.csv`
- `data/external_ke_takahashi2012_second_family_residuals.csv`
- `data/external_ke_takahashi2012_second_family_residuals_summary.json`
- The source is Ke and Takahashi (2012), Soils and Foundations, DOI 10.1016/j.sandf.2012.07.010.
- The gate uses a small rights-safe transcription from Table 6 for Specimen A-60: the lower-gradient state at `i_max = 0.45` initializes the zone-specific particle-loss baseline, and the higher-gradient state at `i_max = 0.51` is the held-out residual check across zones A-C.
- The current run gives MAE 0.321 percentage points, RMSE 0.425 percentage points and held-out-zone R2 0.823 for particle-loss percentage. This is independent of the Lee et al. (2021) A/B validation and supports a second laboratory-family residual endpoint check.
- This is still bounded evidence. It is not field validation, not a full time-history validation, not calibrated dam-safety prediction and not Sterpi/Chang/Zhu residual closure.

Additional field-scale experimental test-bed comparison:

- `code/external_full_trajectory_validation.py`
- `data/external_alvkarleby_section_day_metrics.csv`
- `data/external_alvkarleby_turbidity_long.csv`
- `data/external_model_path_to_weir_mapping.csv`
- `data/external_alvkarleby_field_model_join.csv`
- `data/external_alvkarleby_field_validation_summary.json`
- `data/external_source_manifest.csv`
- `data/external_claim_gate_summary.json`
- The source is the Älvkarleby embankment test-dam seepage/turbidity dataset, Mendeley Data V2, DOI 10.17632/zhfx2g7s7b.2, licensed CC BY 4.0.
- The raw Mendeley ZIP is not included in the upload supplement. It is downloaded from the DOI/API or kept locally outside the upload package under `external_raw_sources_not_for_upload`.
- The comparison maps the computed Dijkstra pathway envelope to eight downstream test-bed sections and compares relative section ranking against processed seepage and turbidity observations.
- The current gate reports Spearman 0.429 for predicted versus observed section score, top-2 hit fraction 0.00, mean absolute section-proportion error 0.091 and relative centroid error 0.042.
- This is a bounded field-scale experimental test-bed comparison. It is not calibrated flow-rate modelling, failure-time prediction, comparison with an in-service dam, or Sterpi/Chang/Zhu residual closure.

Rights and digitization files added for the external validation layer:

- `README_sources.md`
- `DIGITIZATION_METHODS.md`
- `LICENSES_AND_RIGHTS.md`
- `data/external_source_manifest.csv`

Q1 novelty positioning gate:

- `code/novelty_positioning_gate.py`
- `data/novelty_positioning_matrix_q1_cg_recent.csv`
- `data/novelty_positioning_claims.csv`
- `data/novelty_positioning_gate_summary.json`
- This gate converts the existing recent Computers and Geotechnics novelty matrix into auditable claims. It supports novelty only for the selective graph-guided DEM activation operator. It blocks novelty claims based merely on combining FEM, Dijkstra and DEM, and it does not create residual validation against Sterpi, Chang, Zhu, field data or operational dam-safety performance.

Versioned release for this submission: https://github.com/gabrielmontufar/article-126-internal-erosion-dem-fem/releases/tag/v1.0.7-theory-proof-20260531






